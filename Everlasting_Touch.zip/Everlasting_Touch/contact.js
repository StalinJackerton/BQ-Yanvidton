function alert() {
  console.log("success");
  var name = document.forms["contactForm"]["firstName"];
  var email = document.forms["contactForm"]["email"];
  var subject = document.forms["contactForm"]["subject"];
  var text = document.forms["contactForm"]["textInput"];

  if (name == '') {
    window.alert("Please enter your name.");
    name.focus();
    return false;
  }

  if (email.value ==  '' || email.value.indexOf('@') == -1 || email.value.indexOf('.') == -1){ 
      window.alert("Please enter a valid email address."); 
      email.focus(); 
      return false; 
  }

  if (subject == '') {
    window.alert("Please enter your subject.");
    subject.focus();
    return false;
  }

  if (text == '') {
    window.alert("Please enter a brief description.");
    text.focus();
    return false;
  }
}

    
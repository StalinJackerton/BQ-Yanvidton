const $geolocateButton = document.getElementById('geolocation-button');
$geolocateButton.addEventListener('click', geolocate);

function geolocate() {
    if (window.navigator && window.navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(onGeolocateSuccess, onGeolocateError);
    }
}

function onGeolocateSuccess(coordinates) {
    const { latitude, longitude } = coordinates.coords;
    console.log('Found coordinates: ', latitude, longitude);
    window.alert("Thank you for sharing your lcoation with us. Here are some events near your current location.");
    $('#myModal').modal('hide');
  }
  
  function onGeolocateError(error) {
    console.warn(error.code, error.message);
   
    if (error.code === 1) {
      window.alert("We will not be able to provide you information about events near you without your location.");
    } else if (error.code === 2) {
      window.alert("We are sorry, but your current location is unavailable.");
    } else if (error.code === 3) {
      window.alert("Request Timeout");
    }
}

